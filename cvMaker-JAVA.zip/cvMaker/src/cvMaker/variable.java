package cvMaker;

public class variable {
String name;
int From;
int To;
int age;
String Seconary;
String Higher_Seconary;
String hobby;
String Address;
String college;
String Skills;
String experiance;
String email;
String Phone;

public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return Phone;
}
public void setPhone(String phone) {
	Phone = phone;
}
public int getFrom() {
	return From;
}
public void setFrom(int from) {
	From = from;
}
public int getTo() {
	return To;
}
public void setTo(int to) {
	To = to;
}
public String getSeconary() {
	return Seconary;
}
public void setSeconary(String seconary) {
	Seconary = seconary;
}
public String getHigher_Seconary() {
	return Higher_Seconary;
}
public void setHigher_Seconary(String higher_Seconary) {
	Higher_Seconary = higher_Seconary;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public String getSkills() {
	return Skills;
}
public void setSkills(String skills) {
	Skills = skills;
}
public String getExperiance() {
	return experiance;
}
public void setExperiance(String experiance) {
	this.experiance = experiance;
}
public String getHobby() {
	return hobby;
}
public void setHobby(String hobby) {
	this.hobby = hobby;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

public String getCollege() {
	return college;
}
public void setCollege(String college) {
	this.college = college;
}
	
}
