package cvMaker;

public class fgd {
	public void mfun(){
		variable v2=new variable();
		v2.getHobby();
		v2.getAddress();
		v2.getAge();
		v2.getCollege();
		v2.getEmail();
		v2.getExperiance();
		v2.getFrom();
		v2.getTo();
		v2.getHigher_Seconary();
		v2.getName();
		v2.getPhone();
		v2.getSeconary();
		v2.getSkills();
		
	}

}
