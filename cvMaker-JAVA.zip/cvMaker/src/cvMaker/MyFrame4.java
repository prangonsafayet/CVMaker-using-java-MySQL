package cvMaker;

import java.sql.*;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.AncestorListener;
import javax.swing.*;

public class MyFrame4 extends JFrame implements ActionListener{
	
	
	public JPanel panel1 = new JPanel();
	public JPanel panel2 = new JPanel();
	public JPanel panel3 = new JPanel();
	public JPanel panel4 = new JPanel();
	public JPanel panel5 = new JPanel();
	public JPanel panel6 = new JPanel();
	public JPanel panel7 = new JPanel();
	public JPanel panel8 = new JPanel();
	public static final long serialVersionUID = 1L;
    public JPanel contentPane;
	
	TextField tf=new TextField("Test",10);
	JLabel l1=new JLabel("Create beautiful, professional resumes in minutes, free.");
	JLabel l2=new JLabel("Write your resumes effortlessly");
	JLabel l3=new JLabel("Login/SignUp");
	JLabel lp=new JLabel("                                                                       ");
	JLabel lp1=new JLabel("                                                                       ");
	JLabel lp2=new JLabel("                                                                       ");
	JLabel lp3=new JLabel("                                                               ");
	JLabel lp4=new JLabel("                             ");
	JLabel l4=new JLabel("CV Originator");
	JLabel l5=new JLabel("Choose your template and start creating your resume");
	JButton b=new JButton("Create a CV now");
	JButton b5 = new JButton("Create");
	
	JButton login=new JButton("Login");
	JButton cancel=new JButton("Cancel");
	
	JButton login1=new JButton("Submit");
	
	JLabel l1s=new JLabel("First Name");
	JTextField fName=new JTextField(200);
	JLabel l2s=new JLabel("Last Name");
	JTextField lName=new JTextField(200);
	JLabel l3s=new JLabel("UserName");
	JTextField uName=new JTextField(200);
	JLabel l4s=new JLabel("Password");
	JTextField pass=new JTextField(200);
	JLabel l6s=new JLabel("Email");
	JTextField email=new JTextField(200);
	JLabel l7s=new JLabel("Contact No.");
	JTextField contact=new JTextField(200);
	
	Choice cc = new Choice();
	
	JMenuBar menuBar = new JMenuBar();
	JMenuBar menuBar2 = new JMenuBar();
	JMenuBar menuBar3 = new JMenuBar();
		
	JMenu menu = new JMenu("Login/SignUp");
	JMenu menu2 = new JMenu("Login/SignUp");
	JMenuItem menuItem1 = new JMenuItem("Login");
	JMenuItem menuItem2 = new JMenuItem("SignUp");
	JButton buttonlg = new JButton("Logout");
	
	Icon warnIcon5 = new ImageIcon("8.png");
    JButton button55 = new JButton(warnIcon5);
	Icon warnIcon6 = new ImageIcon("9.jpg");
    JButton button66 = new JButton(warnIcon6);
    
	Icon warnIcon2 = new ImageIcon("strawberry.jpg");
    JButton button23 = new JButton(warnIcon2);
	
	Icon warnIcon23 = new ImageIcon("strawberry.jpg");
    JButton button2333 = new JButton(warnIcon23);
	
	Icon warnIcon24 = new ImageIcon("strawberry.jpg");
    JButton button2344 = new JButton(warnIcon24);
	
	JLabel l11=new JLabel("User Name");
	//JTextField uName=new JTextField(200);
	JLabel l22=new JLabel("Password");
	//JTextField pass=new JTextField(200);
	
	Icon warnIcon = new ImageIcon("1.png");
	JButton button2 = new JButton(warnIcon);
	
	Icon warnIcon22 = new ImageIcon("2.jpg");
	JButton button222 = new JButton(warnIcon22);
	
	Icon warnIcon33 = new ImageIcon("3.jpg");
	JButton button233 = new JButton(warnIcon33);
	
	Icon warnIcon44 = new ImageIcon("4.jpg");
	JButton button244 = new JButton(warnIcon44);
	
	JLabel Summary=new JLabel("Summary");
	JTextField Seconary=new JTextField(2000);
	JLabel Education=new JLabel("Education");
	JTextField Higher_Secondary=new JTextField(2000);
	JLabel EmploymentHistory=new JLabel("Employment History");
	JTextField Address=new JTextField(2000);
	JLabel Hobbies=new JLabel("Hobbies & Interests");
	JTextField hobby=new JTextField(2000);
	JLabel skills=new JLabel("Professional Skills");
	JTextField Skills=new JTextField(2000);
	JLabel Languages=new JLabel("Languages");
	JTextField experiance=new JTextField(2000);
	JLabel References=new JLabel("References");
	JTextField name=new JTextField(2000);
	JLabel References1=new JLabel("References");
	JTextField Phone=new JTextField(2000);
			
			
	JButton save=new JButton("Save");
	
	public MyFrame4(){
		
		
		super("Main Page");
		
	    setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		menu1();
		
	    initMenu();
		
		getContentPane().setBackground(new Color(26,188,156));
		setSize(1300,2000);
		setLocation(100,100);
		setLayout(null);
		
		
	}
	
	public void menu1(){
	    
		
		button2344.setLayout(null);
	    button2344.setBounds(0, 0, 50, 35);
		button2344.setBackground(new Color(0,0,0));
		button2344.setForeground(new Color(0,0,0));
		
		button2344.addActionListener(new MenuAction(panel3));
		
		menuBar.add(Box.createRigidArea(new Dimension(100,40)));
		
		menuBar.add(button2344);
		
		menuBar.add(lp4);
		menuBar.add(l2);
		menuBar.add(lp);
		menuBar.add(lp1);
		//menuBar.add(lp2);
		menuBar.add(lp3);
		
		
		menu.setForeground(new Color(255,255,255));
		
		 menuBar.add(menu);
		 menu.add(menuItem1);
		 menu.add(menuItem2);
		    
		menuItem1.addActionListener(new MenuAction(panel1));
		menuItem2.addActionListener(new MenuAction(panel2));
		
		menuBar.setOpaque(true);
        menuBar.setBackground(Color.black);
	    
	    setJMenuBar(menuBar);
		//setJMenuBar(menuBar2);
		//menuBar.setVisible(false);
		//menuBar2.setVisible(false);
		
	}
	
	
	public void menu2(){
	    
		button23.setLayout(null);
	    button23.setBounds(0, 0, 10, 35);
		button23.setBackground(new Color(0,0,0));
		button23.setForeground(new Color(0,0,0));
		
		buttonlg.setBounds(0, 0, 580, 30);
		buttonlg.setBackground(new Color(0,0,0));
		buttonlg.setForeground(new Color(255,255,255));
		
		button23.addActionListener(new MenuAction(panel6));
		buttonlg.addActionListener(new MenuAction(panel7));
		
		menuBar2.add(Box.createRigidArea(new Dimension(100,40)));
		
		
		menuBar2.add(button23);
		menuBar2.add(lp4);
		menuBar2.add(l2);
		menuBar2.add(lp);
		menuBar2.add(lp1);
		//menuBar.add(lp2);
		menuBar2.add(lp3);
		
		
		menuBar2.add(buttonlg);
		menuBar2.setOpaque(true);
        menuBar2.setBackground(Color.black);
		
	    
	    
		setJMenuBar(menuBar2);
		//menuBar.setVisible(false);
		//menuBar2.setVisible(false);
		
	}
	
	public void menu3(){
	    
		
		button2333.setLayout(null);
	    button2333.setBounds(0, 0, 5, 35);
		button2333.setBackground(new Color(0,0,0));
		button2333.setForeground(new Color(0,0,0));
		
		button2333.addActionListener(new MenuAction(panel8));
		
		menuBar3.add(Box.createRigidArea(new Dimension(100,40)));
		
		menuBar3.add(button2333);
		
		menuBar3.add(lp4);
		menuBar3.add(l2);
		menuBar3.add(lp);
		menuBar3.add(lp1);
		//menuBar.add(lp2);
		menuBar3.add(lp3);
		
		
		menu2.setForeground(new Color(255,255,255));
		
		 menuBar3.add(menu2);
		 menu2.add(menuItem1);
		 menu2.add(menuItem2);
		    
		menuItem1.addActionListener(new MenuAction(panel1));
		menuItem2.addActionListener(new MenuAction(panel2));
		
		menuBar3.setOpaque(true);
        menuBar3.setBackground(Color.black);
	    
	    setJMenuBar(menuBar3);
		//setJMenuBar(menuBar2);
		//menuBar.setVisible(false);
		//menuBar2.setVisible(false);
		
	}
	
public class MenuAction implements ActionListener {

	    public JPanel panel;
	    public MenuAction(JPanel pnl) {
	        this.panel = pnl;
	       
	    }
	    @Override
	    public void actionPerformed(ActionEvent e) {
	    	if (this.panel ==  panel1) {
	    		panel2.setVisible(false);
	    		panel3.setVisible(false);
	    		panel4.setVisible(false);
	    		changePanel1(panel);
	    	}
	    	if (this.panel == panel2) {
	    		panel3.setVisible(false);
	    		panel4.setVisible(false);
	    		panel1.setVisible(false);
	    		changePanel2(panel);
	    }
	    	if (this.panel ==  panel3) {
	    		//initMenu();
	    		panel2.setVisible(false);
	    		panel1.setVisible(false);
	    		panel4.setVisible(false);
	    		changePanel3(panel);
	    	}
	    	if (this.panel ==  panel4) {
	    		panel2.setVisible(false);
	    		panel3.setVisible(false);
	    		panel1.setVisible(false);
	    		changePanel4(panel);
	    	}
			if (this.panel ==  panel5) {
	    		panel2.setVisible(false);
	    		panel3.setVisible(false);
	    		panel1.setVisible(false);
	    		changePanel5(panel);
	    	}
			if (this.panel ==  panel6) {
	    		
		    
	    		changePanel6(panel);
	    	}
			if (this.panel ==  panel7) {
	    		
		    
	    		changePanel7(panel);
	    	}
			if (this.panel ==  panel8) {
	    		
		    
	    		changePanel8(panel);
	    	}


	}
}
	
	public void initMenu() {
		
		//menuBar.setVisible(true);
		
		b.setBounds(550, 570, 160, 50);
		b.setBorder(new RoundedBorder(10));
		b.setBackground(new Color(52, 73, 94));
		b.setForeground(new Color(255,255,255));
		
		l1.setBounds(260,50, 1000, 100);
		l1.setForeground(new Color(255,255,255));
		l1.setFont(new Font("Courier New", Font.BOLD, 25));
		
		l4.setBounds(550,10, 1000, 100);
		l4.setForeground(new Color(255,255,255));
		l4.setFont(new Font("Courier New", Font.BOLD, 32));
		
		l5.setBounds(180,150, 1000, 100);
		l5.setForeground(new Color(255,255,255));
		l5.setFont(new Font("Courier New", Font.BOLD, 32));
				
				 
				    
				    
	    button2.setBounds(80, 250, 260, 280);
		button2.setBackground(new Color(0,0,0));
		button2.setForeground(new Color(0,0,0));
		
		button222.setBounds(370, 250, 260, 280);
		button222.setBackground(new Color(0,0,0));
		button222.setForeground(new Color(0,0,0));
		
		button233.setBounds(660, 250, 260, 280);
		button233.setBackground(new Color(0,0,0));
		button233.setForeground(new Color(0,0,0));
		
		button244.setBounds(950, 250, 260, 280);
		button244.setBackground(new Color(0,0,0));
		button244.setForeground(new Color(0,0,0));

		add(l4);
		add(l1);
		add(b);
		add(l5);
		add(button2);
		add(button222);
		add(button233);
		add(button244);
				
 
			  
		 b.addActionListener(new MenuAction(panel1));
		 button2.addActionListener(new MenuAction(panel4));
		 //button222.addActionListener(new MenuAction(panel4));
		 //button233.addActionListener(new MenuAction(panel4));
		 //button244.addActionListener(new MenuAction(panel4));

				
				
		l2.setForeground(new Color(255,255,255));
		l3.setForeground(new Color(255,255,255));
		
	    

	}
	
	public void changePanel1(JPanel panel) {
	    getContentPane().removeAll();
	    		 
	    	JLabel dolog=new JLabel("Don't have any account? ");
	        JButton register=new JButton("SignUp");	
			
			button66.setBounds(700, 70, 428, 322);
			//login.setBorder(new RoundedBorder(10)); //10 is the radius
			button66.setBackground(new Color(178,102,255));
			button66.setForeground(new Color(255,255,255));
			
			login.setBounds(250, 200, 100, 40);
			//login.setBorder(new RoundedBorder(10)); //10 is the radius
			login.setBackground(new Color(178,102,255));
			login.setForeground(new Color(255,255,255));
			
			cancel.setBounds(370, 200, 100, 40);
			//cancel.setBorder(new RoundedBorder(10)); //10 is the radius
			cancel.setBackground(new Color(178,102,255));
			cancel.setForeground(new Color(255,255,255));
			
			l11.setBounds(80,50, 1000, 100);
			l11.setForeground(new Color(0,0,0));
			l11.setFont(new Font("Courier New", Font.BOLD, 16));
			
			l22.setBounds(80,100, 1000, 100);
			l22.setForeground(new Color(0,0,0));
			l22.setFont(new Font("Courier New", Font.BOLD, 16));
			
			dolog.setBounds(130,220, 1000, 100);
			dolog.setForeground(new Color(0,0,0));
			dolog.setFont(new Font("Courier New", Font.BOLD, 16));
			
			register.setBounds(360, 260, 100, 20);
			//cancel.setBorder(new RoundedBorder(10)); //10 is the radius
			register.setBackground(new Color(26,188,156));
			register.setForeground(new Color(0,0,0));
			register.setFont(new Font("Courier New", Font.BOLD, 16));
			
			uName.setBounds(300,80, 300, 35);
			pass.setBounds(300,130, 300, 35);
			
			add(l11);
			add(uName);
			add(l22);
			add(pass);
			add(dolog);
			add(register);
			
			add(button66);
			add(login);
			add(cancel);
			
			register.addActionListener(new MenuAction(panel2));
			cancel.addActionListener(new MenuAction(panel8));
			login.addActionListener(new MenuAction2(this,panel));
			
			setSize(1300,700);
			setLocation(100,100);
			setLayout(null);

	   

	    getContentPane().add(panel, BorderLayout.CENTER);
	    getContentPane().doLayout();
	    update(getGraphics());
	}

	public void changePanel2(JPanel panel) {
	    getContentPane().removeAll();
	    
	    JLabel doreg=new JLabel("Already have an account? ");
	    JButton log=new JButton("Login");	
		
		fName.setBounds(300,80, 300, 35);
		lName.setBounds(300,130, 300, 35);
		uName.setBounds(300,180, 300, 35);
		pass.setBounds(300,230, 300, 35);
		email.setBounds(300,280, 300, 35);
		contact.setBounds(300,330, 300, 35);
		
		button55.setBounds(700, 70, 400, 400);
		//login.setBorder(new RoundedBorder(10)); //10 is the radius
		button55.setBackground(new Color(178,102,255));
		button55.setForeground(new Color(255,255,255));
		
		login1.setBounds(250, 400, 100, 40);
		//login.setBorder(new RoundedBorder(10)); //10 is the radius
		login1.setBackground(new Color(178,102,255));
		login1.setForeground(new Color(255,255,255));
		
		cancel.setBounds(370, 400, 100, 40);
		//cancel.setBorder(new RoundedBorder(10)); //10 is the radius
		cancel.setBackground(new Color(178,102,255));
		cancel.setForeground(new Color(255,255,255));
		
		l1s.setBounds(80,50, 1000, 100);
		l1s.setForeground(new Color(0,0,0));
		l1s.setFont(new Font("Courier New", Font.BOLD, 16));
		
		l2s.setBounds(80,100, 1000, 100);
		l2s.setForeground(new Color(0,0,0));
		l2s.setFont(new Font("Courier New", Font.BOLD, 16));
		
		l3s.setBounds(80,150, 1000, 100);
		l3s.setForeground(new Color(0,0,0));
		l3s.setFont(new Font("Courier New", Font.BOLD, 16));
		
		l4s.setBounds(80,200, 1000, 100);
		l4s.setForeground(new Color(0,0,0));
		l4s.setFont(new Font("Courier New", Font.BOLD, 16));
		
		l6s.setBounds(80,250, 1000, 100);
		l6s.setForeground(new Color(0,0,0));
		l6s.setFont(new Font("Courier New", Font.BOLD, 16));
		
		l7s.setBounds(80,300, 1000, 100);
		l7s.setForeground(new Color(0,0,0));
		l7s.setFont(new Font("Courier New", Font.BOLD, 16));
		
		
		doreg.setBounds(130,420, 1000, 100);
		doreg.setForeground(new Color(0,0,0));
		doreg.setFont(new Font("Courier New", Font.BOLD, 16));
		
		log.setBounds(370, 460, 100, 20);
		//cancel.setBorder(new RoundedBorder(10)); //10 is the radius
		log.setBackground(new Color(26,188,156));
		log.setForeground(new Color(0,0,0));
		log.setFont(new Font("Courier New", Font.BOLD, 16));
		
		add(button55);
		add(l1s);
		add(fName);
		add(l2s);
		add(lName);
		add(l3s);
		add(uName);
		add(l4s);
		add(pass);
		add(l6s);
		add(email);
		add(l7s);
		add(contact);
		add(login1);
		add(cancel);
		add(doreg);
		add(log);
		
		log.addActionListener(new MenuAction(panel1));
		cancel.addActionListener(new MenuAction(panel8));
		login1.addActionListener(new MenuAction1(this,panel));
		
		setSize(1300,700);
		setLocation(100,100);
		setLayout(null);
		
		getContentPane().add(panel, BorderLayout.CENTER);
	    getContentPane().doLayout();
		update(getGraphics());
		
		
	}
	
	public void changePanel3(JPanel panel) {
	    getContentPane().removeAll();
	    
	    initMenu();
	   
	    getContentPane().add(panel, BorderLayout.CENTER);
	    getContentPane().doLayout();
	    update(getGraphics());
	    
	    
	}
	public void changePanel4(JPanel panel){
		getContentPane().removeAll();
		
		//panel.setContentPane(new JLabel(new ImageIcon("5.png")));
		
		Seconary.setBounds(300,80, 300, 35);
		Higher_Secondary.setBounds(300,130, 300, 35);
		Address.setBounds(300,180, 300, 35);
		hobby.setBounds(300,230, 300, 35);
		Skills.setBounds(300,280, 300, 35);
		experiance.setBounds(300,330, 300, 35);
		email.setBounds(300,380, 300, 35);
		name.setBounds(300,430, 300, 35);
		Phone.setBounds(300,480, 300, 35);
		
		save.setBounds(250, 550, 100, 40);
		//login.setBorder(new RoundedBorder(10)); //10 is the radius
		save.setBackground(new Color(178,102,255));
		save.setForeground(new Color(255,255,255));
		
		cancel.setBounds(370, 550, 100, 40);
		//cancel.setBorder(new RoundedBorder(10)); //10 is the radius
		cancel.setBackground(new Color(178,102,255));
		cancel.setForeground(new Color(255,255,255));
		
		Summary.setBounds(80,50, 1000, 100);
		Summary.setForeground(new Color(0,0,0));
		Summary.setFont(new Font("Courier New", Font.BOLD, 16));
		
		Education.setBounds(80,100, 1000, 100);
		Education.setForeground(new Color(0,0,0));
		Education.setFont(new Font("Courier New", Font.BOLD, 16));
		
		EmploymentHistory.setBounds(80,150, 1000, 100);
		EmploymentHistory.setForeground(new Color(0,0,0));
		EmploymentHistory.setFont(new Font("Courier New", Font.BOLD, 16));
		
		Hobbies.setBounds(80,200, 1000, 100);
		Hobbies.setForeground(new Color(0,0,0));
		Hobbies.setFont(new Font("Courier New", Font.BOLD, 16));
		
		skills.setBounds(80,250, 1000, 100);
		skills.setForeground(new Color(0,0,0));
		skills.setFont(new Font("Courier New", Font.BOLD, 16));
		
		Languages.setBounds(80,300, 1000, 100);
		Languages.setForeground(new Color(0,0,0));
		Languages.setFont(new Font("Courier New", Font.BOLD, 16));
		
		References.setBounds(80,350, 1000, 100);
		References.setForeground(new Color(0,0,0));
		References.setFont(new Font("Courier New", Font.BOLD, 16));
		
		References1.setBounds(80,400, 1000, 100);
		References1.setForeground(new Color(0,0,0));
		References1.setFont(new Font("Courier New", Font.BOLD, 16));
		
		l6s.setBounds(80,450, 1000, 100);
		l6s.setForeground(new Color(0,0,0));
		l6s.setFont(new Font("Courier New", Font.BOLD, 16));
		
		add(name);
		add(Summary);
		add(Seconary);
		add(Education);
		add(Higher_Secondary);
		add(EmploymentHistory);
		add(Address);
		add(Hobbies);
		add(hobby);
		add(skills);
		add(Skills);
		add(Languages);
		add(experiance);
		add(References);
		add(References1);
		add(email);
		add(Phone);
		add(l6s);
		add(save);
		add(cancel);
		
		cancel.addActionListener(new MenuAction(panel3));
		save.addActionListener(new MenuAction3(this,panel));
		
		setSize(1300,700);
		setLocation(100,100);
		setLayout(null);
				
		 getContentPane().add(panel, BorderLayout.CENTER);
		 getContentPane().doLayout();
		 update(getGraphics());
	}
	public void changePanel5(JPanel panel) {
	    getContentPane().removeAll();
	    
	   menu2();
	   
	    b.setBounds(550, 570, 160, 50);
		b.setBorder(new RoundedBorder(10));
		b.setBackground(new Color(52, 73, 94));
		b.setForeground(new Color(255,255,255));
		
		l1.setBounds(260,50, 1000, 100);
		l1.setForeground(new Color(255,255,255));
		l1.setFont(new Font("Courier New", Font.BOLD, 25));
		
		l4.setBounds(550,10, 1000, 100);
		l4.setForeground(new Color(255,255,255));
		l4.setFont(new Font("Courier New", Font.BOLD, 32));
		
		l5.setBounds(180,150, 1000, 100);
		l5.setForeground(new Color(255,255,255));
		l5.setFont(new Font("Courier New", Font.BOLD, 32));		    
				    
	    button2.setBounds(80, 250, 260, 280);
		button2.setBackground(new Color(0,0,0));
		button2.setForeground(new Color(0,0,0));
		
		button222.setBounds(370, 250, 260, 280);
		button222.setBackground(new Color(0,0,0));
		button222.setForeground(new Color(0,0,0));
		
		button233.setBounds(660, 250, 260, 280);
		button233.setBackground(new Color(0,0,0));
		button233.setForeground(new Color(0,0,0));
		
		button244.setBounds(950, 250, 260, 280);
		button244.setBackground(new Color(0,0,0));
		button244.setForeground(new Color(0,0,0));

		add(l4);
		add(l1);
		//add(b);
		add(l5);
		add(button2);
		add(button222);
		add(button233);
		add(button244);
				
 
			  
		// b.addActionListener(new MenuAction(panel1));
		 button2.addActionListener(new MenuAction(panel4));
		 button222.addActionListener(new MenuAction(panel4));
		 button233.addActionListener(new MenuAction(panel4));
		 button244.addActionListener(new MenuAction(panel4));

				
				
		l2.setForeground(new Color(255,255,255));
		l3.setForeground(new Color(255,255,255));
	   
	    getContentPane().add(panel, BorderLayout.CENTER);
	    getContentPane().doLayout();
	    update(getGraphics());
	    
	    
	}
	public void changePanel6(JPanel panel) {
	    
		getContentPane().removeAll();
	    
		
		l1.setBounds(260,50, 1000, 100);
		l1.setForeground(new Color(255,255,255));
		l1.setFont(new Font("Courier New", Font.BOLD, 25));
		
		l4.setBounds(550,10, 1000, 100);
		l4.setForeground(new Color(255,255,255));
		l4.setFont(new Font("Courier New", Font.BOLD, 32));
		
		l5.setBounds(180,150, 1000, 100);
		l5.setForeground(new Color(255,255,255));
		l5.setFont(new Font("Courier New", Font.BOLD, 32));		    
				    
	    button2.setBounds(80, 250, 260, 280);
		button2.setBackground(new Color(0,0,0));
		button2.setForeground(new Color(0,0,0));
		
		button222.setBounds(370, 250, 260, 280);
		button222.setBackground(new Color(0,0,0));
		button222.setForeground(new Color(0,0,0));
		
		button233.setBounds(660, 250, 260, 280);
		button233.setBackground(new Color(0,0,0));
		button233.setForeground(new Color(0,0,0));
		
		button244.setBounds(950, 250, 260, 280);
		button244.setBackground(new Color(0,0,0));
		button244.setForeground(new Color(0,0,0));

		add(l4);
		add(l1);
		//add(b);
		add(l5);
		add(button2);
		add(button222);
		add(button233);
		add(button244);
				
 
			  
		// b.addActionListener(new MenuAction(panel1));
		 button2.addActionListener(new MenuAction(panel4));
		 button222.addActionListener(new MenuAction(panel4));
		 button233.addActionListener(new MenuAction(panel4));
		 button244.addActionListener(new MenuAction(panel4));

				
				
		l2.setForeground(new Color(255,255,255));
		l3.setForeground(new Color(255,255,255));
	   
	    getContentPane().add(panel, BorderLayout.CENTER);
	    getContentPane().doLayout();
	    update(getGraphics());
	    
	    
	}
	public void changePanel7(JPanel panel) {
	    getContentPane().removeAll();
	    
	   menu3();
	   
	    b.setBounds(550, 570, 160, 50);
		b.setBorder(new RoundedBorder(10));
		b.setBackground(new Color(52, 73, 94));
		b.setForeground(new Color(255,255,255));
		
		l1.setBounds(260,50, 1000, 100);
		l1.setForeground(new Color(255,255,255));
		l1.setFont(new Font("Courier New", Font.BOLD, 25));
		
		l4.setBounds(550,10, 1000, 100);
		l4.setForeground(new Color(255,255,255));
		l4.setFont(new Font("Courier New", Font.BOLD, 32));
		
		l5.setBounds(180,150, 1000, 100);
		l5.setForeground(new Color(255,255,255));
		l5.setFont(new Font("Courier New", Font.BOLD, 32));
				
				 
				    
				    
	    button2.setBounds(80, 250, 260, 280);
		button2.setBackground(new Color(0,0,0));
		button2.setForeground(new Color(0,0,0));
		
		button222.setBounds(370, 250, 260, 280);
		button222.setBackground(new Color(0,0,0));
		button222.setForeground(new Color(0,0,0));
		
		button233.setBounds(660, 250, 260, 280);
		button233.setBackground(new Color(0,0,0));
		button233.setForeground(new Color(0,0,0));
		
		button244.setBounds(950, 250, 260, 280);
		button244.setBackground(new Color(0,0,0));
		button244.setForeground(new Color(0,0,0));

		add(l4);
		add(l1);
		add(b);
		add(l5);
		add(button2);
		add(button222);
		add(button233);
		add(button244);
				
 
			  
		 b.addActionListener(new MenuAction(panel1));
		 //button2.addActionListener(new MenuAction(panel4));
		// button222.addActionListener(new MenuAction(panel4));
		// button233.addActionListener(new MenuAction(panel4));
		// button244.addActionListener(new MenuAction(panel4));

				
				
		l2.setForeground(new Color(255,255,255));
		l3.setForeground(new Color(255,255,255));
	   
	    getContentPane().add(panel, BorderLayout.CENTER);
	    getContentPane().doLayout();
	    update(getGraphics());
	    
	    
	}
	public void changePanel8(JPanel panel) {
	    getContentPane().removeAll();
	    
	 
	   b.setBounds(550, 570, 160, 50);
		b.setBorder(new RoundedBorder(10));
		b.setBackground(new Color(52, 73, 94));
		b.setForeground(new Color(255,255,255));
		
		l1.setBounds(260,50, 1000, 100);
		l1.setForeground(new Color(255,255,255));
		l1.setFont(new Font("Courier New", Font.BOLD, 25));
		
		l4.setBounds(550,10, 1000, 100);
		l4.setForeground(new Color(255,255,255));
		l4.setFont(new Font("Courier New", Font.BOLD, 32));
		
		l5.setBounds(180,150, 1000, 100);
		l5.setForeground(new Color(255,255,255));
		l5.setFont(new Font("Courier New", Font.BOLD, 32));
				
				 
				    
				    
	    button2.setBounds(80, 250, 260, 280);
		button2.setBackground(new Color(0,0,0));
		button2.setForeground(new Color(0,0,0));
		
		button222.setBounds(370, 250, 260, 280);
		button222.setBackground(new Color(0,0,0));
		button222.setForeground(new Color(0,0,0));
		
		button233.setBounds(660, 250, 260, 280);
		button233.setBackground(new Color(0,0,0));
		button233.setForeground(new Color(0,0,0));
		
		button244.setBounds(950, 250, 260, 280);
		button244.setBackground(new Color(0,0,0));
		button244.setForeground(new Color(0,0,0));

		add(l4);
		add(l1);
		add(b);
		add(l5);
		add(button2);
		add(button222);
		add(button233);
		add(button244);
				
 
			  
		 b.addActionListener(new MenuAction(panel1));
		 //button2.addActionListener(new MenuAction(panel4));
		// button222.addActionListener(new MenuAction(panel4));
		// button233.addActionListener(new MenuAction(panel4));
		// button244.addActionListener(new MenuAction(panel4));

				
				
		l2.setForeground(new Color(255,255,255));
		l3.setForeground(new Color(255,255,255));
	   
	    getContentPane().add(panel, BorderLayout.CENTER);
	    getContentPane().doLayout();
	    update(getGraphics());
	    
	    
	}

	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		

	}
}
class MenuAction1 implements ActionListener {
	MyFrame4 lr;
	ResultSet s=null;
	JPanel panel;
	DataAccess da = new DataAccess(); 
		public MenuAction1(MyFrame4 lr,JPanel panel){
			this.lr=lr;
			this.panel=panel;			
		}
	    public void actionPerformed(ActionEvent event) {
	    	 //JOptionPane.showMessageDialog(null,"What is your name?", null);
	    	//JOptionPane.showMessageDialog(null,"You must provide a department no.");
			
			String sql="INSERT INTO sign (fName, lName, uName, pass, email, contact) VALUES ('"+lr.fName.getText()+"', '"+
																							lr.lName.getText()+"', '"+
																							lr.uName.getText()+"', '"+
																							lr.pass.getText()+"', '"+
																							lr.email.getText()+"', '"+
																							lr.contact.getText()+"')";
			String sql1="INSERT INTO login (uName, pass) VALUES ('"+lr.uName.getText()+"', '"+lr.pass.getText()+"')";																				
																							
			System.out.println(sql);
			boolean flag=true;
			String dn=lr.fName.getText();
			String dn1=lr.lName.getText();
			String dn2=lr.uName.getText();
			String dn3=lr.pass.getText();
			String dn4=lr.email.getText();
			String dn5=lr.contact.getText();
		    
			if(dn.length()==0){
			JOptionPane.showMessageDialog(lr, "field can not be empty!");
			System.out.println("You must provide a first name.");
			flag=false;
		}
		else if(dn1.length()==0){
			JOptionPane.showMessageDialog(lr, "field can not be empty!");
			System.out.println("You must provide a last name.");
			flag=false;
		}
		else if(dn2.length()==0){
			JOptionPane.showMessageDialog(lr, "field can not be empty!");
			System.out.println("You must provide a user name.");
			flag=false;
		}
		else if(dn3.length()==0){
			JOptionPane.showMessageDialog(lr, "field can not be empty!");
			System.out.println("You must provide a passwrd.");
			flag=false;
		}
		else if(dn4.length()==0){
			JOptionPane.showMessageDialog(lr, "field can not be empty!");
			System.out.println("You must provide a email.");
			flag=false;
		}
		else if(dn5.length()==0){
			JOptionPane.showMessageDialog(lr, "field can not be empty!");
			System.out.println("You must provide a contact.");
			flag=false;
		}
		else {
			da.updateDB(sql);
			da.updateDB(sql1);
			
			lr.changePanel5(panel);
		}
			
			
	}
	   }

class MenuAction2 implements ActionListener {
	MyFrame4 lr2;
	JPanel panel;
	ResultSet s=null;
	DataAccess da2 = new DataAccess(); 
		public MenuAction2(MyFrame4 lr2,JPanel panel){
			this.lr2=lr2; 
			this.panel=panel;
		}
	    public void actionPerformed(ActionEvent event) {
	    	 //JOptionPane.showMessageDialog(null,"What is your name?", null);
	    	//JOptionPane.showMessageDialog(null,"You must provide a department no.");
			
			String sql="SELECT * FROM login WHERE uName='"+lr2.uName.getText()+"' and pass='"+lr2.pass.getText()+"';";
			
			boolean flag=true;
			
			String dn2=lr2.uName.getText();
			String dn3=lr2.pass.getText();
		
		    System.out.println(sql);
			
			if(dn2.length()==0){
			JOptionPane.showMessageDialog(lr2, "field can not be empty!");
			System.out.println("You must provide a user name.");
			flag=false;
		}
		else if(dn3.length()==0){
			JOptionPane.showMessageDialog(lr2, "field can not be empty!");
			System.out.println("You must provide a password.");
			flag=false;
		}
		else {
			s=da2.getData(sql);
			
				
				try{
					if(s.next())
				{
					
					lr2.changePanel5(panel);
					
				}
				else{
					
					JOptionPane.showMessageDialog(lr2, "Username or Password Doesn't match!");
					//System.out.println("DB Read Error !");
				}
         }
			catch(Exception ex){
            JOptionPane.showMessageDialog(lr2, "Username or Password Doesn't match!");
            //ex.printStackTrace();
        }
		}
			
			
			
			
			
			
	}
}

class MenuAction3 implements ActionListener {
	MyFrame4 lr3;
	ResultSet s3=null;
	JPanel panel;
	DataAccess da3 = new DataAccess(); 
	variable v=new variable();
		public MenuAction3(MyFrame4 lr3,JPanel panel){
			this.lr3=lr3;
			this.panel=panel;	
			System.out.println("hello");
		}
	    public void actionPerformed(ActionEvent event) {
	    	 //JOptionPane.showMessageDialog(null,"What is your name?", null);
	    	//JOptionPane.showMessageDialog(null,"You must provide a department no.");
			
			String sql="INSERT INTO template (name, Address, email, Phone, Secondary, Higher_Secondary, hobby, Skills, experiance) VALUES ('"+lr3.name.getText()+"','"+
																							lr3.Address.getText()+"', '"+
																							lr3.email.getText()+"','"+
																							lr3.Phone.getText()+"', '"+
																							lr3.Seconary.getText()+"', '"+
																							lr3.Higher_Secondary.getText()+"', '"+
																							lr3.hobby.getText()+"', '"+
																							lr3.Skills.getText()+"', '"+
																							lr3.experiance.getText()+"')";
				
			
			
																							
			System.out.println(sql);
			

			v.setName("mamun");
			
			boolean flag=true;
			String dn=lr3.Seconary.getText();
			String dn1=lr3.Higher_Secondary.getText();
			String dn2=lr3.Address.getText();
			String dn3=lr3.hobby.getText();
			String dn4=lr3.Skills.getText();
			String dn5=lr3.experiance.getText();
			String dn6=lr3.email.getText();
			String dn7=lr3.Phone.getText();
			String dn8=lr3.name.getText();
			
			String ss = "Select name FROM template where email = 'gh'";
			
			variable v=new variable();
			//v.setName("mamun");
			
			v.setName(dn8);
			//v.setName(dn8);
			//v.setName(dn8);
			
			//da3.updateDB(sql);
			
			System.out.println(v.getName());
		    
		    if(dn.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			
			flag=false;
		}
		else if(dn1.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			System.out.println("You must provide a last name.");
			flag=false;
		}
		else if(dn2.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			System.out.println("You must provide a user name.");
			flag=false;
		}
		else if(dn3.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			System.out.println("You must provide a passwrd.");
			flag=false;
		}
		else if(dn4.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			System.out.println("You must provide a email.");
			flag=false;
		}
		else if(dn5.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			System.out.println("You must provide a contact.");
			flag=false;
		}
		else if(dn6.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			System.out.println("You must provide a contact.");
			flag=false;
		}
		else if(dn7.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			System.out.println("You must provide a contact.");
			flag=false;
		}
		else if(dn8.length()==0){
			JOptionPane.showMessageDialog(lr3, "field can not be empty!");
			System.out.println("You must provide a contact.");
			flag=false;
		}
		else {
			da3.updateDB(sql);
			
			//lr.changePanel5(panel);
		}
			
			
			
			
			
			//lr.changePanel5(panel);
			
			/*s=da.getData(sql);
			
				lr.changePanel5(panel);
				
				try{
					if(s.next())
				{
					lr.changePanel5(panel);
					
				}
				else{
					
					JOptionPane.showMessageDialog(lr, "field can not be empty!");
					//System.out.println("DB Read Error !");
				}
         }
			catch(Exception ex){
            JOptionPane.showMessageDialog(lr, "field can not be empty!");
            //ex.printStackTrace();
        } */
			
	}
	   }