package cvMaker;

public class CvInterface{
	public static void main(String [] arg){
		MyFrame4 mf = new MyFrame4();
		mf.setVisible(true); 
		//mf.repaint();
  
	}
}
